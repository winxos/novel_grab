# AIST novel grab
> novel grab service using python3

> winxos, AISTLAB 2017-03-31

## INSTALL:
``` pip3 install aist_novel_grab ```

## USAGE:

``` python
from novel_grab import novel_grab
novel_grab.download('url of the novel chapters')
```

*Just for educational purpose, take care of yourself.*

