# AIST novel grab
> novel grab service using python3

> winxos, AISTLAB 2017-03-31

## INSTALL:
``` pip3 install aist_novel_grab ```

## USAGE:

``` python
    d = Downloader('http://book.zongheng.com/showchapter/403749.html')
    d.start()
    print(d.get_info())
```

*Just for educational purpose, take care of yourself.*



